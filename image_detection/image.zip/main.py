import sys
import os
import easyocr
from judge_content import judge_content
from judge_position import judge_position

def process_image(image_path):
    print(f"处理图片: {image_path}")
    # 用中英文模型识别
    reader_cn = easyocr.Reader(['ch_sim', 'en'], gpu=False)
    results_cn = reader_cn.readtext(image_path)
    # 用英文模型识别
    reader_en = easyocr.Reader(['en'], gpu=False)
    results_en = reader_en.readtext(image_path)
    # 合并所有文本内容（去重）
    all_results = results_cn + results_en
    texts = []
    bboxes = []
    for item in all_results:
        if item[1] not in texts:
            texts.append(item[1])
            bboxes.append(item[0])
    if not texts:
        print("未检测到文本区域")
        return
    print("检测到的所有文本内容：")
    for i, text in enumerate(texts):
        print(f"  区域{i+1}: {text}")
    # 3. 判断内容
    result = judge_content(texts)
    if result == "错误标识":
        print("错误标识")
        return
    print(f"\n检测到的显式标识内容：{result}")
    # 4. 判断位置
    idx = texts.index(result)
    bbox = bboxes[idx]
    x_coords = [point[0] for point in bbox]
    y_coords = [point[1] for point in bbox]
    x, y, w, h = int(min(x_coords)), int(min(y_coords)), int(max(x_coords)-min(x_coords)), int(max(y_coords)-min(y_coords))
    pos_result = judge_position(image_path, (x, y, w, h))
    print(pos_result)

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("用法: python main.py <图片路径>")
        sys.exit(1)
    image_path = sys.argv[1]
    if not os.path.exists(image_path):
        print("图片文件不存在")
        sys.exit(1)
    process_image(image_path) 